PUNTA CAVALIERO ANDROID APP PROJECT

Included:
- Open Play baseline V3.2.16
- Double Elimination baseline: GOLD LOGO CIRCLE
- Offline Android WebView launcher
- Shared app-local HTTPS origin so localStorage works consistently
- JavaScript and DOM storage enabled
- No internet connection required for the two managers

BUILD IN ANDROID STUDIO:
1. Extract this ZIP.
2. Open the PuntaCavalieroAndroid folder in Android Studio.
3. Allow Gradle Sync to finish.
4. Build > Build App Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the APK location when the build finishes.

PACKAGE:
com.puntacavaliero.courtmanager

NOTE:
The two approved HTML baselines were copied into app/src/main/assets and were not rewritten.
